/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"
#include "SEGGER_SYSVIEW.h" // For SEGGER SystemView debugging
#include "string.h"
#include "stdio.h" // For printf (ensure UART/SWV is configured for output)
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
// Removed TIM_HandleTypeDef htim3_ultrasonic; - using htim3 directly
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

#define ULTRASONIC_TRIG_PIN       GPIO_PIN_4
#define ULTRASONIC_TRIG_PORT      GPIOB
#define ADC_BUFFER_SIZE           100 // Or 1000 for 1000 samples
#define ADC_RESOLUTION_BITS       12
#define ADC_MAX_VALUE             ((1 << ADC_RESOLUTION_BITS) - 1) // 4095 for 12-bit
#define ADC_INTERNAL_VREF         5.0 // Internal ADC reference voltage (Vref+) in Volts
#define VOLTAGE_DIVIDER_RATIO     1.0 // ASSUMING your LDR module outputs 0-3.3V directly

// Adjust these values based on your specific STM32's HCLK frequency
// For 16MHz HCLK, 1us = 16 cycles
#define HCLK_FREQ_MHZ             (HAL_RCC_GetHCLKFreq() / 1000000)

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

SPI_HandleTypeDef hspi1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim3;

/* USER CODE BEGIN PV */
//----------------------UV----------------------
volatile uint32_t ic_timestamp_rising = 0;
volatile uint32_t ic_timestamp_falling = 0;
volatile uint8_t capture_rising_edge_done = 0; // State machine for echo capture
volatile uint32_t measured_distance_cm = 0;

SemaphoreHandle_t xUltrasonicEchoSemaphore = NULL;

//----------------------ADC----------------------
volatile uint32_t adc_dma_buffer[ADC_BUFFER_SIZE];
volatile uint8_t adc_half_transfer_complete = 0;
volatile uint8_t adc_full_transfer_complete = 0;

//----------------------SPI----------------------
uint8_t txbuff[2];			//address,value
uint8_t rx_x,rx_y,rx_z;		//to store the values of xyz
volatile uint8_t xFL, yFL, zFL; //flags for xyz
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM3_Init(void);
static void MX_ADC1_Init(void);
static void MX_SPI1_Init(void);
/* USER CODE BEGIN PFP */
void DWT_Init(void);
void DelayMicroseconds(uint32_t us);
void UltrasonicSensorTask(void *argument);
void AdcProcessingTask(void *argument);
void SPIProcessingTask(void *argument);
static void MX_NVIC_Init(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM1_Init();
  MX_TIM3_Init();
  MX_ADC1_Init();
  MX_SPI1_Init();
  /* USER CODE BEGIN 2 */
  MX_NVIC_Init();
  DWT_Init(); // Initialize DWT for microsecond delays
  SEGGER_SYSVIEW_Conf(); // Configure SystemView

  // Create binary semaphore for ultrasonic echo capture event
  xUltrasonicEchoSemaphore = xSemaphoreCreateBinary();
  configASSERT(xUltrasonicEchoSemaphore != NULL);

  HAL_TIM_Base_Start(&htim1); // Start TIM1 if needed for other purposes
  HAL_TIM_Base_Start(&htim3); // Start TIM3 base timer, input capture will be started later

  // Start ADC conversion in DMA mode
  // The ADC will continuously convert and transfer data to adc_dma_buffer.
  // Since DMA is in Circular mode, it will wrap around when the buffer is full.
  if (HAL_ADC_Start_DMA(&hadc1, adc_dma_buffer, ADC_BUFFER_SIZE) != HAL_OK)
  {
    Error_Handler(); // Handle error if DMA start fails
  }

  // Create FreeRTOS tasks

  BaseType_t task_created_ultrasonic = xTaskCreate(UltrasonicSensorTask, "UltrasonicSensorTask", 256, NULL, 3, NULL);
  configASSERT(task_created_ultrasonic == pdPASS);

  // ADC tasks
  BaseType_t task_created_adc = xTaskCreate(AdcProcessingTask, "AdcProcessingTask", 256, NULL, 2, NULL); // Lower priority than ultrasonic
  configASSERT(task_created_adc == pdPASS);

  //i2c for accelerometer
  BaseType_t task_created_spi = xTaskCreate(SPIProcessingTask, "SPITask", 256, NULL, 2, NULL); // Lower priority than ultrasonic
   configASSERT(task_created_spi == pdPASS);

  //----------------------SPI----------------------
   //PULL CS PIN LOW
    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, RESET);
    txbuff[0]=0x20;  //address of CTRL REG
    txbuff[1]=0x37;      //value

    HAL_SPI_Transmit(&hspi1, txbuff, 2, 50);

    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, SET); // CS PULLED HIGH
		//----------------------SPI----------------------
  // Start the FreeRTOS scheduler
  vTaskStartScheduler();


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  // This part of the code is typically not reached in a FreeRTOS application
  // unless the scheduler fails to start or is explicitly stopped.
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV2;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_480CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */
  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */
  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 15;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */
  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */
  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_IC_InitTypeDef sConfigIC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */
  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 15;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_IC_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim3, &sConfigIC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */
  /* USER CODE END TIM3_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA2_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 6, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET);

  /*Configure GPIO pin : PE3 */
  GPIO_InitStruct.Pin = GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : PB4 */
  GPIO_InitStruct.Pin = GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
/**
 * @brief Initializes the DWT for microsecond delays.
 * Required for DelayMicroseconds function.
 */
void DWT_Init(void)
{
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;  // Enable trace and debug block
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;             // Enable cycle counter
    DWT->CYCCNT = 0; // Reset counter
}

/**
 * @brief Provides a blocking delay in microseconds using DWT.
 * @param us Number of microseconds to delay.
 */
void DelayMicroseconds(uint32_t us)
{
    uint32_t start_cycle = DWT->CYCCNT;
    // Calculate cycles to wait based on HCLK frequency
    uint32_t cycles_to_wait = us * HCLK_FREQ_MHZ; // HCLK_FREQ_MHZ is in MHz, so multiply by us
    while ((DWT->CYCCNT - start_cycle) < cycles_to_wait);
}

/**
 * @brief FreeRTOS Task for Ultrasonic Sensor Measurement.
 * @param argument Not used.
 */
void UltrasonicSensorTask(void *argument)
{
    // Give the semaphore once at the beginning to ensure the first xSemaphoreTake doesn't block forever
    // if the ISR is somehow triggered before the task is ready. Or, more robustly,
    // ensure the initial state is clean. For this, we'll just ensure the ISR is disabled.
    // xSemaphoreGive(xUltrasonicEchoSemaphore); // Not needed if task manages start/stop

    TickType_t xLastWakeTime;
    const TickType_t xFrequency = pdMS_TO_TICKS(500); // Measure every 500ms

    xLastWakeTime = xTaskGetTickCount(); // Initialize xLastWakeTime

    while (1)
    {
        vTaskDelayUntil(&xLastWakeTime, xFrequency); // Delay until the next cycle

        // Reset timer counter before starting a new measurement
        __HAL_TIM_SET_COUNTER(&htim3, 0);
        capture_rising_edge_done = 0; // Reset state machine for new measurement
        measured_distance_cm = 0; // Reset distance for new measurement

        // Ensure input capture polarity is set to RISING for the start of echo pulse
        __HAL_TIM_SET_CAPTUREPOLARITY(&htim3, TIM_CHANNEL_2, TIM_INPUTCHANNELPOLARITY_RISING);
        // Enable the input capture interrupt for TIM3 Channel 2
        HAL_TIM_IC_Start_IT(&htim3, TIM_CHANNEL_2);


        // Generate trigger pulse
        HAL_GPIO_WritePin(ULTRASONIC_TRIG_PORT, ULTRASONIC_TRIG_PIN, GPIO_PIN_RESET);
        DelayMicroseconds(2);
        HAL_GPIO_WritePin(ULTRASONIC_TRIG_PORT, ULTRASONIC_TRIG_PIN, GPIO_PIN_SET);
        DelayMicroseconds(10);
        HAL_GPIO_WritePin(ULTRASONIC_TRIG_PORT, ULTRASONIC_TRIG_PIN, GPIO_PIN_RESET);

        // Wait for echo capture semaphore with a timeout (e.g., 100ms for max range ~17m)
        if (xSemaphoreTake(xUltrasonicEchoSemaphore, pdMS_TO_TICKS(100)) == pdTRUE)
        {
            // Data received and processed in ISR, now print/use it
            SEGGER_SYSVIEW_PrintfHost("Distance: %lu cm\r\n", measured_distance_cm);
            printf("Distance: %lu cm\r\n", measured_distance_cm); // Requires UART/SWV printf setup
        }
        else
        {
            // Timeout occurred, no valid echo received
            measured_distance_cm = 0; // Indicate no valid reading
            SEGGER_SYSVIEW_PrintfHost("Timeout or no Echo\r\n");
            printf("Timeout or no Echo\r\n"); // Requires UART/SWV printf setup
            // Ensure the interrupt is disabled if it wasn't already (e.g., if no falling edge)
            HAL_TIM_IC_Stop_IT(&htim3, TIM_CHANNEL_2);
        }
    }
}

/**
 * @brief TIM3 Interrupt Handler.
 * This function should be called from the TIM3_IRQHandler in stm32f4xx_it.c
 * (or directly implemented if you override the default HAL handler).
 */
void TIM3_IRQHandler(void)
{
    // Ensure this is the input capture interrupt for Channel 2
    if (__HAL_TIM_GET_FLAG(&htim3, TIM_FLAG_CC2) != RESET)
    {
        if (__HAL_TIM_GET_IT_SOURCE(&htim3, TIM_IT_CC2) != RESET)
        {
            // Clear the interrupt flag
            __HAL_TIM_CLEAR_IT(&htim3, TIM_IT_CC2);

            if (capture_rising_edge_done == 0)
            {
                // First edge: Rising edge of echo pulse
                ic_timestamp_rising = HAL_TIM_ReadCapturedValue(&htim3, TIM_CHANNEL_2);
                capture_rising_edge_done = 1;
                // Switch to capture falling edge
                __HAL_TIM_SET_CAPTUREPOLARITY(&htim3, TIM_CHANNEL_2, TIM_INPUTCHANNELPOLARITY_FALLING);
            }
            else
            {
                // Second edge: Falling edge of echo pulse
                ic_timestamp_falling = HAL_TIM_ReadCapturedValue(&htim3, TIM_CHANNEL_2);

                // Calculate pulse duration (in microseconds, as timer tick is 1us)
                uint32_t pulse_duration;
                if (ic_timestamp_falling >= ic_timestamp_rising)
                {
                    pulse_duration = ic_timestamp_falling - ic_timestamp_rising;
                }
                else
                {
                    // Handle timer overflow if it happened between rising and falling edges
                    // This is rare for short ultrasonic pulses but good practice
                    pulse_duration = (htim3.Init.Period + 1 - ic_timestamp_rising) + ic_timestamp_falling;
                }

                // Calculate distance in cm: (time in us * speed of sound in cm/us) / 2
                // Speed of sound approx 0.0343 cm/us at 20°C
                measured_distance_cm = (uint32_t)((double)pulse_duration * 0.0343 / 2.0);

                // Reset state for next measurement
                capture_rising_edge_done = 0;
                // Switch back to capture rising edge for the next cycle
                __HAL_TIM_SET_CAPTUREPOLARITY(&htim3, TIM_CHANNEL_2, TIM_INPUTCHANNELPOLARITY_RISING);
                // Disable the input capture interrupt until the next trigger
                HAL_TIM_IC_Stop_IT(&htim3, TIM_CHANNEL_2); // Use HAL_TIM_IC_Stop_IT for clean disable

                // Give semaphore to unblock the FreeRTOS task
                BaseType_t higher_priority_task_woken = pdFALSE;
                xSemaphoreGiveFromISR(xUltrasonicEchoSemaphore, &higher_priority_task_woken);
                portYIELD_FROM_ISR(higher_priority_task_woken);
            }
        }
    }
    // If you have other TIM3 interrupts (e.g., update event), you might need to call
    // HAL_TIM_IRQHandler(&htim3); here to process them, but for a dedicated IC, this is fine.
}
// ... (UltrasonicSensorTask and DWT functions) ...

/**
 * @brief FreeRTOS Task for ADC Data Processing.
 * @param argument Not used.
 */
void AdcProcessingTask(void *argument)
{
    TickType_t xLastWakeTime;
    const TickType_t xFrequency = pdMS_TO_TICKS(100); // Check for new ADC data every 100ms

    xLastWakeTime = xTaskGetTickCount();

    while (1)
    {
        vTaskDelayUntil(&xLastWakeTime, xFrequency);

        // Process half of the buffer (first half) if ready
        if (adc_half_transfer_complete)
        {
            adc_half_transfer_complete = 0; // Clear the flag

            double sum_voltage = 0.0f;
            for (int i = 0; i < ADC_BUFFER_SIZE / 2; i++)
            {
                // Convert raw ADC value to voltage at the pin (0-3.3V)
                float voltage_at_pin = (float)adc_dma_buffer[i] * (ADC_INTERNAL_VREF / ADC_MAX_VALUE);
                // Scale back to original input voltage (0-5V) using voltage divider ratio
                float original_input_voltage = voltage_at_pin / VOLTAGE_DIVIDER_RATIO;
                sum_voltage += original_input_voltage;
            }
            float average_voltage = sum_voltage / (ADC_BUFFER_SIZE / 2);

            SEGGER_SYSVIEW_PrintfHost("ADC Half-Buffer Avg: %.3fV (0-5V scaled)\r\n", average_voltage);
            printf("ADC Half-Buffer Avg: %.3fV (0-5V scaled)\r\n", average_voltage);
        }

        // Process full buffer (second half) if ready
        if (adc_full_transfer_complete)
        {
            adc_full_transfer_complete = 0; // Clear the flag

            double sum_voltage = 0.0f;
            for (int i = ADC_BUFFER_SIZE / 2; i < ADC_BUFFER_SIZE; i++)
            {
                float voltage_at_pin = (float)adc_dma_buffer[i] * (ADC_INTERNAL_VREF / ADC_MAX_VALUE);
                float original_input_voltage = voltage_at_pin / VOLTAGE_DIVIDER_RATIO;
                sum_voltage += original_input_voltage;
            }
            float average_voltage = sum_voltage / (ADC_BUFFER_SIZE / 2);
            vTaskDelay(pdMS_TO_TICKS(2000));
            SEGGER_SYSVIEW_PrintfHost("ADC Full-Buffer Avg: %.3fV (0-5V scaled)\r\n", average_voltage);
            printf("ADC Full-Buffer Avg: %.3fV (0-5V scaled)\r\n", average_voltage);
        }
    }
}
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
  if(hadc->Instance == ADC1) // Check if the callback is for ADC1
  {
    adc_full_transfer_complete = 1; // Set flag when the entire buffer is filled
  }
}
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef* hadc)
{
  if(hadc->Instance == ADC1) // Check if the callback is for ADC1
  {
    adc_half_transfer_complete = 1; // Set flag when half of the buffer is filled
  }
}

static void MX_NVIC_Init(void)
{
  /* TIM3_IRQn interrupt configuration */
  // Priority set for FreeRTOS compatibility:
  // Lower numerical value means higher priority.
  // Must be >= configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY
  // (or configMAX_SYSCALL_INTERRUPT_PRIORITY for older FreeRTOS versions)
  // For STM32F4, typically 5 is a safe priority for peripheral interrupts
  // that call FreeRTOS API functions.
  HAL_NVIC_SetPriority(TIM3_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(TIM3_IRQn);

  /* ADC global interrupt configuration */
  // This is for ADC error/regular callbacks, if enabled.
  // Set priority compatible with FreeRTOS.
  HAL_NVIC_SetPriority(ADC_IRQn, 5, 0); // Assuming ADC_IRQn is the correct IRQ for your ADC
  HAL_NVIC_EnableIRQ(ADC_IRQn);

  /* DMA2_Stream0_IRQn interrupt configuration */
  // This is for DMA transfer complete/half-complete callbacks.
  // Set priority compatible with FreeRTOS.
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 5, 0); // Assuming DMA2 Stream0 is used for ADC
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);
}
void SPIProcessingTask(void *argument)
{
	 while (1)
	  {
		 //2.READ THE VALUE OF X AXIS
		 	  	  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, RESET);
		 	  	  txbuff[0] = 0x29 | 0x80;  //address to be read
		 	  	  HAL_SPI_Transmit(&hspi1, txbuff,1, 50); 		//transmit the address to be read
		 	  	  HAL_SPI_Receive(&hspi1, &rx_x, 1, 50);		//Receive tore in rx_x
		 	  	  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, SET);

		 	  	vTaskDelay(pdMS_TO_TICKS(2));

		 	  	  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, RESET);
		 	  	  txbuff[0] = 0x2B | 0x80;  //address to be read
		 	  	  HAL_SPI_Transmit(&hspi1, txbuff,1, 50); 		//transmit the address to be read
		 	  	  HAL_SPI_Receive(&hspi1, &rx_y, 1, 50);		//Receive tore in rx_x
		 	  	  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, SET);

		 	  	vTaskDelay(pdMS_TO_TICKS(2));

		 	  	  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, RESET);
		 	  	  txbuff[0] = 0x2D | 0x80;  				//address to be read
		 	  	  HAL_SPI_Transmit(&hspi1, txbuff,1, 50); 	//transmit the address to be read
		 	  	  HAL_SPI_Receive(&hspi1, &rx_z, 1, 50);	//Receive  and store in rx_x
		 	  	  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, SET);

		 	  	  vTaskDelay(pdMS_TO_TICKS(1000));

		 	  	  SEGGER_SYSVIEW_PrintfHost("x: %d, y: %d, z: %d\n", rx_x,rx_y,rx_z);
			      printf("x: %d, y: %d, z: %d\n", rx_x,rx_y,rx_z);

		 	  	  if(rx_x>125 && rx_y<125 && rx_z<125)
		 	  	  {
		 	  		  xFL = 1;
		 	  	  }
		 	  	  else if(rx_x<125 && rx_y>125 && rx_z<125)
		 	  	  {
		 	  		  yFL = 1;
		 	  	  }
		 	  	  else if(rx_x<125 && rx_y<125 && rx_z>125)
		 	  	  {
		 	  		  zFL = 1;
		 	  	  }
		 	  	  else
		 	  	  {
		 	  		  xFL = yFL = zFL = 0;
		 	  	  }

		 	  	  if(xFL || yFL)
		 	  	  {
		 	  		  SEGGER_SYSVIEW_PrintfHost("x: %d, y: %d, z: %d\n", rx_x,rx_y,rx_z);
		 	  		  printf("x: %d, y: %d, z: %d\n", rx_x,rx_y,rx_z);
		 	  	  }

		   }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
